INSERT INTO ServiceDesk (Client_ID, IssueType, Priority, TimeStamp)
VALUES 
(1, 'Air conditioning not working', 'High', GETDATE()),
(2, 'Leaking pipe in kitchen', 'Medium', GETDATE()),
(3, 'Electrical wiring malfunction', 'High', GETDATE()),
(4, 'Software bug in control system', 'Low', GETDATE()),
(5, 'Routine maintenance request', 'Low', GETDATE());



INSERT INTO ClientManagement (Name, ServiceHistory, Contracts)
VALUES 
('John Doe', 'HVAC Maintenance', 'Contract A'),
('Jane Smith', 'Plumbing Repair', 'Contract B'),
('Mike Johnson', 'Electrical Installation', 'Contract C'),
('Emily Davis', 'General Maintenance', 'Contract D'),
('Sophia Brown', 'Software Upgrade', 'Contract E');


INSERT INTO ContractManagement (ServiceLevel, StartDate, EndDate, Status)
VALUES 
('Premium', '2023-01-01', '2024-01-01', 'Active'),
('Basic', '2022-05-01', '2023-05-01', 'Expired'),
('Standard', '2023-07-15', '2024-07-15', 'Active'),
('Premium', '2022-10-01', '2023-10-01', 'Expired'),
('Basic', '2023-02-01', '2024-02-01', 'Active');


INSERT INTO FieldServiceManagement (Client_ID, Technician_ID, JobStatus)
VALUES 
(1, 1, 'In Progress'),
(2, 2, 'Completed'),
(3, 3, 'Assigned'),
(4, 4, 'Completed'),
(5, 5, 'Assigned');


INSERT INTO Technician (Name, Skills, AvailabilityStatus)
VALUES 
('Alice Williams', 'HVAC, Electrical', 'Available'),
('Bob Martin', 'Plumbing, HVAC', 'Busy'),
('Charlie Taylor', 'Electrical, Plumbing', 'Available'),
('David Anderson', 'Software, Networking', 'Busy'),
('Eve Thompson', 'General Maintenance, Software', 'Available');


INSERT INTO ServiceRequest (Client_ID, ServiceType, RequestDate, Status)
VALUES 
(1, 'HVAC Repair', GETDATE(), 'Open'),
(2, 'Plumbing Repair', GETDATE(), 'Closed'),
(3, 'Electrical Installation', GETDATE(), 'In Progress'),
(4, 'Software Debugging', GETDATE(), 'Closed'),
(5, 'General Maintenance', GETDATE(), 'Open');


INSERT INTO CustomerSatisfaction (Client_ID, Rating)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 5),
(5, 4);