

CREATE PROCEDURE Assign_Technician
    @req_id INT
AS
BEGIN
    DECLARE @tech_id INT;
    
    
    SELECT TOP 1 @tech_id = Technician_ID 
    FROM Technician 
    WHERE AvailabilityStatus = 'Available';
    
   
    UPDATE ServiceRequest
    SET Status = 'In Progress'
    WHERE Job_ID = @req_id;
    
    
    UPDATE Technician
    SET AvailabilityStatus = 'Busy'
    WHERE Technician_ID = @tech_id;
END;
GO