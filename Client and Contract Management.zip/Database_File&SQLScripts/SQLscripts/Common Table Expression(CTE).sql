WITH OngoingRequests AS (
    SELECT SR.Job_ID, C.Name AS ClientName, SR.ServiceType, SR.Status
    FROM ServiceRequest SR
    JOIN ClientManagement C ON SR.Client_ID = C.Client_ID
    WHERE SR.Status = 'In Progress'
)
SELECT * FROM OngoingRequests;
GO