SELECT 
    SR.Job_ID,
    C.Name AS ClientName,
    T.Name AS TechnicianName,
    SR.ServiceType,
    SR.Status
FROM ServiceRequest SR LEFT JOIN 
	ClientManagement C ON SR.Client_ID = C.Client_ID LEFT JOIN 
	Technician T ON SR.Technician_ID = T.Technician_ID;
GO