CREATE TRIGGER UpdateTechnicianStatus
ON FieldServiceManagement
AFTER UPDATE
AS
BEGIN
    
    IF EXISTS (SELECT * FROM inserted WHERE JobStatus = 'Completed')
    BEGIN
        UPDATE Technician
        SET AvailabilityStatus = 'Available'
        WHERE Technician_ID IN (SELECT Technician_ID FROM inserted WHERE JobStatus = 'Completed');
    END
END;
GO