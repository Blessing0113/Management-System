USE ApexCareSolutions

CREATE TABLE ServiceDesk (
    Call_ID INT IDENTITY(1,1) PRIMARY KEY,  
    Client_ID INT,  
    IssueType NVARCHAR(255),  
    Priority VARCHAR(10) CHECK (Priority IN ('Low', 'Medium', 'High')),
    TimeStamp DATETIME DEFAULT GETDATE(),  
    FOREIGN KEY (Client_ID) REFERENCES ClientManagement(Client_ID) ON DELETE CASCADE
);


CREATE TABLE ClientManagement (
    Client_ID INT IDENTITY(1,1) PRIMARY KEY,  
    Name NVARCHAR(255) NOT NULL,  
    ServiceHistory TEXT,  
    Contracts NVARCHAR(MAX)  
);


CREATE TABLE ContractManagement (
    Contract_ID INT IDENTITY(1,1) PRIMARY KEY,  
    ServiceLevel NVARCHAR(50),  
    StartDate DATE,  
    EndDate DATE,  
    Status NVARCHAR(50)  
);


CREATE TABLE FieldServiceManagement (
    Job_ID INT IDENTITY(1,1) PRIMARY KEY,  
    Client_ID INT,  
    Technician_ID INT,  
    JobStatus NVARCHAR(50),  
    FOREIGN KEY (Client_ID) REFERENCES ClientManagement(Client_ID) ON DELETE CASCADE,
    FOREIGN KEY (Technician_ID) REFERENCES Technician(Technician_ID) ON DELETE CASCADE
);


CREATE TABLE Technician (
    Technician_ID INT IDENTITY(1,1) PRIMARY KEY,  
    Name NVARCHAR(255),  
    Skills NVARCHAR(255),
    AvailabilityStatus NVARCHAR(50) DEFAULT 'Available'  
);

CREATE TABLE ServiceRequest (
    Job_ID INT IDENTITY(1,1) PRIMARY KEY,  
    Client_ID INT,  
    ServiceType NVARCHAR(255),  
    RequestDate DATETIME DEFAULT GETDATE(),  
    Status NVARCHAR(50),  
    FOREIGN KEY (Client_ID) REFERENCES ClientManagement(Client_ID) ON DELETE CASCADE
);


CREATE TABLE CustomerSatisfaction (
    FeedBack_ID INT IDENTITY(1,1) PRIMARY KEY,  
    Client_ID INT,  
    Rating INT CHECK (Rating BETWEEN 1 AND 5),  
    FOREIGN KEY (Client_ID) REFERENCES ClientManagement(Client_ID) ON DELETE CASCADE
);