﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using FULL_PROJECT_.DataAccess;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using BCrypt.Net;
using FULL_PROJECT_.Business;

namespace FULL_PROJECT_.Services
{
    public interface IAuthService
    {
        Task<bool> RegisterAsync(string email, string password);
        Task<string> LoginAsync(string email, string password);
    }

    public class AuthService : IAuthService
    {
        private readonly DatabaseAccess _databaseAccess;
        private readonly IConfiguration _configuration;

        public AuthService(DatabaseAccess databaseAccess, IConfiguration configuration)
        {
            _databaseAccess = databaseAccess;
            _configuration = configuration;
        }

        public async Task<bool> RegisterAsync(string email, string password)
        {
            var existingUser = await _databaseAccess.GetUserByEmail(email);
            if (existingUser != null)
            {
                return false; // User already exists
            }

            string passwordHash = BCrypt.Net.BCrypt.HashPassword(password);
            return await _databaseAccess.CreateUser(email, passwordHash);
        }

        public async Task<string> LoginAsync(string email, string password)
        {
            var user = await _databaseAccess.GetUserByEmail(email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
            {
                return null; // Invalid credentials
            }

            return GenerateJwtToken(user);
        }

        private string GenerateJwtToken(User user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
        new Claim(JwtRegisteredClaimNames.Sub, user.Email),
        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
    };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
    
}