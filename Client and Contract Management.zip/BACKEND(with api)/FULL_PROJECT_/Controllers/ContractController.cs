﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using FULL_PROJECT_.DataAccess;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace FULL_PROJECT_.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ContractController : ControllerBase
    {
        private readonly DatabaseAccess _databaseAccess;
        private readonly ILogger<ContractController> _logger;

        public ContractController(DatabaseAccess databaseAccess, ILogger<ContractController> logger)
        {
            _databaseAccess = databaseAccess;
            _logger = logger;
        }

        [HttpGet]
        public ActionResult<List<ContractManagement>> GetContracts()
        {
            try
            {
                var contracts = _databaseAccess.GetContracts();
                return Ok(contracts);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching contracts");
                return StatusCode(500, new { message = "An error occurred while fetching contracts" });
            }
        }

        [HttpPost]
        public ActionResult<ContractManagement> InsertContract([FromBody] ContractManagement contract)
        {
            try
            {
                var result = _databaseAccess.InsertContract(contract);
                if (result)
                {
                    return Ok(contract);
                }
                return BadRequest(new { message = "Failed to insert contract" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while inserting contract");
                return StatusCode(500, new { message = "An error occurred while inserting the contract" });
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<bool> DeleteContract(int id)
        {
            try
            {
                var result = _databaseAccess.DeleteContract(id);
                if (result)
                {
                    return Ok(true);
                }
                return NotFound(new { message = $"Contract with ID {id} not found or could not be deleted" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error occurred while deleting contract with ID {id}");
                return StatusCode(500, new { message = $"An error occurred while deleting the contract with ID {id}" });
            }
        }
    }
}