﻿using Microsoft.AspNetCore.Mvc;
using FULL_PROJECT_.Services;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace FULL_PROJECT_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(IAuthService authService, ILogger<AuthController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel model)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid model state for registration");
                return BadRequest(ModelState);
            }

            _logger.LogInformation($"Attempting to register user: {model.Email}");
            var result = await _authService.RegisterAsync(model.Email, model.Password);
            if (result)
            {
                _logger.LogInformation($"Registration successful for user: {model.Email}");
                return Ok(new { message = "Registration successful" });
            }
            _logger.LogWarning($"Registration failed for user: {model.Email}");
            return BadRequest(new { message = "Registration failed" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid model state for login");
                return BadRequest(ModelState);
            }

            _logger.LogInformation($"Attempting login for user: {model.Email}");
            var token = await _authService.LoginAsync(model.Email, model.Password);
            if (token != null)
            {
                _logger.LogInformation($"Login successful for user: {model.Email}");
                return Ok(new { token });
            }
            _logger.LogWarning($"Login failed for user: {model.Email}");
            return Unauthorized(new { message = "Invalid credentials" });
        }
    }

    public class RegisterModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class LoginModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}