﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using FULL_PROJECT_.DataAccess;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace FULL_PROJECT_.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly DatabaseAccess _databaseAccess;
        private readonly ILogger<ClientController> _logger;

        public ClientController(DatabaseAccess databaseAccess, ILogger<ClientController> logger)
        {
            _databaseAccess = databaseAccess;
            _logger = logger;
        }

        [HttpGet]
        public ActionResult<List<ClientManagement>> GetClients()
        {
            try
            {
                var clients = _databaseAccess.GetClients();
                return Ok(clients);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching clients");
                return StatusCode(500, new { message = "An error occurred while fetching clients" });
            }
        }

        [HttpPost]
        public ActionResult<ClientManagement> InsertClient([FromBody] ClientManagement client)
        {
            try
            {
                var result = _databaseAccess.InsertClient(client);
                if (result)
                {
                    return Ok(client);
                }
                return BadRequest(new { message = "Failed to insert client" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while inserting client");
                return StatusCode(500, new { message = "An error occurred while inserting the client" });
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<bool> DeleteClient(int id)
        {
            try
            {
                var result = _databaseAccess.DeleteClient(id);
                if (result)
                {
                    return Ok(true);
                }
                return NotFound(new { message = $"Client with ID {id} not found or could not be deleted" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error occurred while deleting client with ID {id}");
                return StatusCode(500, new { message = $"An error occurred while deleting the client with ID {id}" });
            }
        }
    }
}