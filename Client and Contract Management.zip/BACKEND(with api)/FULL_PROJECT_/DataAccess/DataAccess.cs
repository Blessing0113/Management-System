﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using FULL_PROJECT_.Business;

namespace FULL_PROJECT_.DataAccess
{
    public class DatabaseAccess
    {
        private readonly string _connectionString;

        public DatabaseAccess(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<ClientManagement> GetClients()
        {
            List<ClientManagement> clients = new List<ClientManagement>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT ClientID, Name, ServiceHistory, Contracts FROM ClientManagement";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            clients.Add(new ClientManagement
                            {
                                ClientID = reader.GetInt32(reader.GetOrdinal("ClientID")),
                                Name = reader.IsDBNull(reader.GetOrdinal("Name")) ? null : reader.GetString(reader.GetOrdinal("Name")),
                                ServiceHistory = reader.IsDBNull(reader.GetOrdinal("ServiceHistory")) ? null : reader.GetString(reader.GetOrdinal("ServiceHistory")),
                                Contracts = reader.IsDBNull(reader.GetOrdinal("Contracts")) ? null : reader.GetString(reader.GetOrdinal("Contracts"))
                            });
                        }
                    }
                }
            }
            return clients;
        }

        public bool InsertClient(ClientManagement client)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "INSERT INTO ClientManagement (Name, ServiceHistory, Contracts) VALUES (@Name, @ServiceHistory, @Contracts); SELECT SCOPE_IDENTITY();";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", client.Name);
                    command.Parameters.AddWithValue("@ServiceHistory", (object)client.ServiceHistory ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Contracts", (object)client.Contracts ?? DBNull.Value);
                    var result = Convert.ToInt32(command.ExecuteScalar());
                    client.ClientID = result;
                    return result > 0;
                }
            }
        }

        public bool DeleteClient(int clientId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "DELETE FROM ClientManagement WHERE ClientID = @ClientID";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ClientID", clientId);
                    var result = command.ExecuteNonQuery();
                    return result > 0;
                }
            }
        }

        public List<ContractManagement> GetContracts()
        {
            List<ContractManagement> contracts = new List<ContractManagement>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT ContractID, ServiceLevel, StartDate, EndDate, Status FROM ContractManagement";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            contracts.Add(new ContractManagement
                            {
                                ContractID = reader.GetInt32(reader.GetOrdinal("ContractID")),
                                ServiceLevel = reader.IsDBNull(reader.GetOrdinal("ServiceLevel")) ? null : reader.GetString(reader.GetOrdinal("ServiceLevel")),
                                StartDate = reader.GetDateTime(reader.GetOrdinal("StartDate")),
                                EndDate = reader.GetDateTime(reader.GetOrdinal("EndDate")),
                                Status = reader.IsDBNull(reader.GetOrdinal("Status")) ? null : reader.GetString(reader.GetOrdinal("Status"))
                            });
                        }
                    }
                }
            }
            return contracts;
        }

        public bool InsertContract(ContractManagement contract)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "INSERT INTO ContractManagement (ServiceLevel, StartDate, EndDate, Status) VALUES (@ServiceLevel, @StartDate, @EndDate, @Status); SELECT SCOPE_IDENTITY();";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ServiceLevel", contract.ServiceLevel);
                    command.Parameters.AddWithValue("@StartDate", contract.StartDate);
                    command.Parameters.AddWithValue("@EndDate", contract.EndDate);
                    command.Parameters.AddWithValue("@Status", contract.Status);
                    var result = Convert.ToInt32(command.ExecuteScalar());
                    contract.ContractID = result;
                    return result > 0;
                }
            }
        }

        public bool DeleteContract(int contractId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "DELETE FROM ContractManagement WHERE ContractID = @ContractID";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ContractID", contractId);
                    var result = command.ExecuteNonQuery();
                    return result > 0;
                }
            }
        }
    }
}