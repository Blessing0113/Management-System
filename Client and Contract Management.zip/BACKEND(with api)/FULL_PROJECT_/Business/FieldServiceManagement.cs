﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FULL_PROJECT_.Business
{
    public class FieldServiceManagement
    {

        private int _jobID;
        private int _clientID;
        private int _technicianID;
        private string _jobStatus;


        public int JobID
        {
            get { return _jobID; }
            set { _jobID = value; }
        }
        public int ClientID
        {
            get { return _clientID; }
            set { _clientID = value; }
        }
        public int TechnicianID
        {
            get { return _technicianID; }
            set { _technicianID = value; }
        }
        public string JobStatus
        {
            get { return _jobStatus; }
            set { _jobStatus = value; }
        }


        public FieldServiceManagement(int jobID, int clientID, int technicianID, string jobStatus)
        {
            _jobID = jobID;
            _clientID = clientID;
            _technicianID = technicianID;
            _jobStatus = jobStatus;
        }


        public void AssignTechnician(int jobID, int technicianID)
        {

        }

        public void UpdateJobStatus(string status)
        {

        }

        public string GetJobDetails()
        {
            return $"Job ID: {_jobID}, Status: {_jobStatus}";
        }
    }
}
