﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace FULL_PROJECT_.Business
//{
//    public class ClientManagement
//    {
//        private int Client_ID;
//        private string Name;
//        private List<string> ServiceHistory;
//        private List<ContractManagement> _contracts;

//        // Property for Client_ID
//        public int ClientID
//        {
//            get { return Client_ID; }
//            set { Client_ID = value; }
//        }

//        // Property for Name
//        public string name
//        {
//            get { return Name; }
//            set { Name = value; }
//        }

//        // Property for ServiceHistory
//        public List<string> ServiceHist
//        {
//            get { return ServiceHistory; }
//            set { ServiceHistory = value; }
//        }

//        // Property for Contracts
//        public List<ContractManagement> Contracts
//        {
//            get { return _contracts; }
//            set { _contracts = value; }
//        }

//        // Constructor
//        public ClientManagement(int client_ID, string Name)
//        {
//            Client_ID = client_ID;
//            this.Name = Name; // Corrected this line
//            ServiceHistory = new List<string>();
//            _contracts = new List<ContractManagement>();
//        }

//        // Method to update client profile (implement logic as needed)
//        public void UpdateProfile()
//        {
//            // Implement logic to update the client's profile
//        }

//        // Method to add a contract to the client's contract list
//        public void AddContract(ContractManagement contract)
//        {
//            _contracts.Add(contract);
//        }

//        // Method to retrieve the client's service history
//        public List<string> GetServiceHistory()
//        {
//            return ServiceHistory;
//        }
//    }
//}


public class ClientManagement
{
    public int ClientID { get; set; }
    public string Name { get; set; }
    public string ServiceHistory { get; set; }
    public string Contracts { get; set; }
}
