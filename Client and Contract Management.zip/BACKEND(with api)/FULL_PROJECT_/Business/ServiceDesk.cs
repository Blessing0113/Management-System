﻿using FULL_PROJECT_.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FULL_PROJECT_.Business
{
    public class ServiceDesk
    {

        private int Call_ID;
        private int Client_ID;
        private string IssueType;
        private string Priority;
        private DateTime Timestamp;


        public int CallID
        {
            get { return Call_ID; }
            set { Call_ID = value; }
        }
        public int ClientID
        {
            get { return Client_ID; }
            set { Client_ID = value; }
        }
        public string Issue_Type
        {
            get { return IssueType; }
            set { IssueType = value; }
        }
        public string Prior
        {
            get { return Priority; }
            set { Priority = value; }
        }
        public DateTime Timestam
        {
            get { return Timestamp; }
            set { Timestamp = value; }
        }

        public ServiceDesk()
        { }


        public ServiceDesk(int callID, int clientID, string issueType, string priority, DateTime timestamp)
        {
            Call_ID = callID;
            Client_ID = clientID;
            IssueType = issueType;
            Priority = priority;
            Timestamp = timestamp;
        }


        public void LogIssue()
        {
            //DataAccess D = new DataAccess();
            //D.GetServiceDeskIssues();

        }

        public void AssignTechnician()
        {

        }
    }
}
