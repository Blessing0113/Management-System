﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace FULL_PROJECT_.Business
//{
//    public class ContractManagement
//    {

//        private int Contract_ID;
//        private string ServiceLevel;
//        private DateTime StartDate;
//        private DateTime EndDate;
//        private string _status;


//        public int ContractID
//        {
//            get { return Contract_ID; }
//            set { Contract_ID = value; }
//        }
//        public string Service_Level
//        {
//            get { return ServiceLevel; }
//            set { ServiceLevel = value; }
//        }
//        public DateTime Start_Date
//        {
//            get { return StartDate; }
//            set { StartDate = value; }
//        }
//        public DateTime End_Date
//        {
//            get { return EndDate; }
//            set { EndDate = value; }
//        }
//        public string Status
//        {
//            get { return _status; }
//            set { _status = value; }
//        }


//        public ContractManagement(int contractID, string serviceLevel, DateTime startDate, DateTime endDate, string status)
//        {
//            ContractID = contractID;
//            ServiceLevel = serviceLevel;
//            StartDate = startDate;
//            EndDate = endDate;
//            _status = status;
//        }


//        public void RenewContract()
//        {

//        }

//        public string CheckContractStatus()
//        {
//            return _status;
//        }

//        public string GetContractDetails()
//        {
//            return $"Contract ID: {ContractID}, Service Level: {ServiceLevel}";
//        }
//    }
//}

public class ContractManagement
{
    public int ContractID { get; set; }
    public string ServiceLevel { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Status { get; set; }
}