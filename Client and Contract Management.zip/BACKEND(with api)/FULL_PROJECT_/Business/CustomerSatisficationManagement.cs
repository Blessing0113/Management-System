﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FULL_PROJECT_.Business
{
    public class CustomerSatisfactionManagement
    {

        private int _feedbackID;
        private int _clientID;
        private string _comments;
        private int _rating;


        public int FeedbackID
        {
            get { return _feedbackID; }
            set { _feedbackID = value; }
        }
        public int ClientID
        {
            get { return _clientID; }
            set { _clientID = value; }
        }
        public string Comments
        {
            get { return _comments; }
            set { _comments = value; }
        }
        public int Rating
        {
            get { return _rating; }
            set { _rating = value; }
        }


        public CustomerSatisfactionManagement(int feedbackID, int clientID, string comments, int rating)
        {
            _feedbackID = feedbackID;
            _clientID = clientID;
            _comments = comments;
            _rating = rating;
        }


        public void LogComplaint()
        {

        }

        public void ScheduleFollowUp()
        {

        }

        public string GetFeedbackSummary()
        {
            return $"Feedback ID: {_feedbackID}, Rating: {_rating}, Comments: {_comments}";
        }
    }
}
