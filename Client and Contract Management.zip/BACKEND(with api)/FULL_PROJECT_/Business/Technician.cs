﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FULL_PROJECT_.Business
{
    public class Technician
    {

        private int _technicianID;
        private string _name;
        private List<string> _skills;
        private bool _availabilityStatus;


        public int TechnicianID
        {
            get { return _technicianID; }
            set { _technicianID = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public List<string> Skills
        {
            get { return _skills; }
            set { _skills = value; }
        }
        public bool AvailabilityStatus
        {
            get { return _availabilityStatus; }
            set { _availabilityStatus = value; }
        }


        public Technician(int technicianID, string name)
        {
            _technicianID = technicianID;
            _name = name;
            _skills = new List<string>();
        }


        public void ReceiveJobAssignment(int jobID)
        {

        }

        public void UpdateJobStatus(int jobID, string status)
        {

        }

        public string GetTechnicianDetails()
        {
            return $"Technician ID: {_technicianID}, Name: {_name}";
        }
    }
}
