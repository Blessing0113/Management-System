﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FULL_PROJECT_.Business
{
    public class ServiceRequest
    {

        private int _requestID;
        private int _clientID;
        private string _serviceType;
        private DateTime _requestDate;
        private string _status;


        public int RequestID
        {
            get { return _requestID; }
            set { _requestID = value; }
        }
        public int ClientID
        {
            get { return _clientID; }
            set { _clientID = value; }
        }
        public string ServiceType
        {
            get { return _serviceType; }
            set { _serviceType = value; }
        }
        public DateTime RequestDate
        {
            get { return _requestDate; }
            set { _requestDate = value; }
        }
        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        public ServiceRequest(int requestID, int clientID, string serviceType, DateTime requestDate, string status)
        {
            _requestID = requestID;
            _clientID = clientID;
            _serviceType = serviceType;
            _requestDate = requestDate;
            _status = status;
        }


        public void UpdateRequestStatus(string newStatus)
        {

        }

        public void AssignToTechnician(Technician technician)
        {

        }

        public string GetRequestDetails()
        {
            return $"Request ID: {_requestID}, Service Type: {_serviceType}, Status: {_status}";
        }
    }
}
