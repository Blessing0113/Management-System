const apiUrl = 'https://localhost:7222/api';
let token = localStorage.getItem('token');

// Function to check if the user is authenticated
function checkAuth() {
    if (token) {
        document.getElementById('authSection').classList.add('hidden');
        document.getElementById('mainContent').classList.remove('hidden');
        fetchClients();
        fetchContracts();
    } else {
        document.getElementById('authSection').classList.remove('hidden');
        document.getElementById('mainContent').classList.add('hidden');
    }
}

// Login event listener
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${apiUrl}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const responseBody = await response.text();
        if (response.ok) {
            const data = JSON.parse(responseBody);
            token = data.token;
            localStorage.setItem('token', token);
            checkAuth();
        } else {
            alert(`Login failed. Server response: ${responseBody}`);
        }
    } catch (error) {
        console.error('Login error:', error);
        alert(`An error occurred during login: ${error.message}`);
    }
});

// Register event listener
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    try {
        const response = await fetch(`${apiUrl}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (response.ok) {
            alert('Registration successful. Please login.');
            document.getElementById('registerForm').reset();
        } else {
            alert('Registration failed. Please try again.');
        }
    } catch (error) {
        console.error('Registration error:', error);
        alert('An error occurred during registration.');
    }
});

// Logout event listener
document.getElementById('logoutButton').addEventListener('click', () => {
    localStorage.removeItem('token');
    token = null;
    checkAuth();
});

// Fetch clients and display them in a table
async function fetchClients() {
    try {
        const response = await fetch(`${apiUrl}/client`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const clients = await response.json();
            displayClients(clients);
        } else {
            console.error('Failed to fetch clients');
            document.getElementById('clients').innerHTML = '<p>Failed to load clients. Please try again later.</p>';
        }
    } catch (error) {
        console.error('Error fetching clients:', error);
        document.getElementById('clients').innerHTML = '<p>Error loading clients. Please try again later.</p>';
    }
}

// Function to display clients in the table
function displayClients(clients) {
    const clientTableBody = document.getElementById('clientTableBody');
    clientTableBody.innerHTML = ''; // Clear any existing rows

    clients.forEach(client => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.clientID}</td>
            <td>${client.name}</td>
            <td>${client.serviceHistory}</td>
            <td>${client.contracts}</td>
            <td><button class="deleteClientButton" data-client-id="${client.clientID}">Delete</button></td>
        `;
        clientTableBody.appendChild(row);
    });

    // Attach delete event listeners after populating the table
    document.querySelectorAll('.deleteClientButton').forEach(button => {
        button.addEventListener('click', async (e) => {
            const clientId = e.target.getAttribute('data-client-id');
            await deleteClient(clientId);
        });
    });
}

// Add client event listener
document.getElementById('addClientForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const clientName = document.getElementById('clientName').value;
    const clientServiceHistory = document.getElementById('clientServiceHistory').value;
    const clientContracts = document.getElementById('clientContracts').value;

    try {
        const response = await fetch(`${apiUrl}/client`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                name: clientName,
                serviceHistory: clientServiceHistory,
                contracts: clientContracts
            })
        });

        if (response.ok) {
            const newClient = await response.json(); // Get the newly created client object
            addClientToTable(newClient); // Add the new client to the table
            document.getElementById('addClientForm').reset(); // Clear the form
        } else {
            alert('Failed to add client. Please try again.');
        }
    } catch (error) {
        console.error('Error adding client:', error);
        alert('An error occurred while adding the client.');
    }
    const newClient = await response.json();
console.log('New client added:', newClient);

});

// Function to add a client row to the table
function addClientToTable(client) {
    const clientTableBody = document.getElementById('clientTableBody');

    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${client.clientID}</td>
        <td>${client.name}</td>
        <td>${client.serviceHistory}</td>
        <td>${client.contracts}</td>
        <td><button class="deleteClientButton" data-client-id="${client.clientID}">Delete</button></td>
    `;

    clientTableBody.appendChild(row);

    // Attach delete event listener for the new row
    row.querySelector('.deleteClientButton').addEventListener('click', async (e) => {
        const clientId = e.target.getAttribute('data-client-id');
        await deleteClient(clientId);
    });
    

}

// Function to delete a client
async function deleteClient(clientId) {
    try {
        const response = await fetch(`${apiUrl}/client/${clientId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            alert('Client deleted successfully.');
            fetchClients(); // Refresh the client list after deletion
        } else {
            alert('Failed to delete client.');
        }
    } catch (error) {
        console.error('Error deleting client:', error);
        alert('An error occurred while deleting the client.');
    }
}

// Add contract event listener
document.getElementById('addContractForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const serviceLevel = document.getElementById('contractServiceLevel').value;
    const startDate = document.getElementById('contractStartDate').value;
    const endDate = document.getElementById('contractEndDate').value;
    const status = document.getElementById('contractStatus').value;

    try {
        const response = await fetch(`${apiUrl}/contract`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` // Ensure token is sent
            },
            body: JSON.stringify({
                serviceLevel,
                startDate,
                endDate,
                status
            })
        });

        if (response.ok) {
            const newContract = await response.json();
            alert('Contract added successfully.');
            // Optionally reset form and refresh contract list
        } else if (response.status === 401) {
            // Token might be expired or invalid, force the user to re-login
            alert('Your session has expired. Please login again.');
            localStorage.removeItem('token');
            checkAuth();
        } else {
            alert('Failed to add contract. Please try again.');
        }
    } catch (error) {
        console.error('Error adding contract:', error);
        alert('An error occurred while adding the contract.');
    }
});

